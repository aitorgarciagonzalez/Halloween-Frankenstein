import * as i0 from '@angular/core';
import { EventEmitter, Component, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

class MonsterCardComponent {
    constructor() {
        this.image = 'assets/frankenstein.svg';
        this.title = 'Criatura desconocida';
        this.description = 'No hay información disponible sobre este expediente.';
        this.buttonText = 'Abrir expediente';
        this.cardAction = new EventEmitter();
    }
    static { this.ɵfac = function MonsterCardComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MonsterCardComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MonsterCardComponent, selectors: [["lib-monster-card"]], inputs: { image: "image", title: "title", description: "description", buttonText: "buttonText" }, outputs: { cardAction: "cardAction" }, standalone: true, features: [i0.ɵɵStandaloneFeature], decls: 12, vars: 5, consts: [[1, "monster-card"], [1, "image-frame"], [3, "src", "alt"], [1, "card-content"], [1, "tag"], [1, "description"], ["type", "button", 3, "click"]], template: function MonsterCardComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "article", 0)(1, "div", 1);
            i0.ɵɵelement(2, "img", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "div", 3)(4, "p", 4);
            i0.ɵɵtext(5, "EXPEDIENTE DE HALLOWEEN");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(6, "h2");
            i0.ɵɵtext(7);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(8, "p", 5);
            i0.ɵɵtext(9);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "button", 6);
            i0.ɵɵlistener("click", function MonsterCardComponent_Template_button_click_10_listener() { return ctx.cardAction.emit(); });
            i0.ɵɵtext(11);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("src", ctx.image, i0.ɵɵsanitizeUrl)("alt", ctx.title);
            i0.ɵɵadvance(5);
            i0.ɵɵtextInterpolate(ctx.title);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.description);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.buttonText);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;margin:20px 0}.monster-card[_ngcontent-%COMP%]{overflow:hidden;border:2px solid #789b62;border-radius:18px;background:linear-gradient(145deg,#263a2b,#111a14);box-shadow:0 10px 24px #0009,inset 0 0 18px #9ac47718;color:#e7f0df;transition:transform .2s,box-shadow .2s}.monster-card[_ngcontent-%COMP%]:hover{transform:translateY(-3px);box-shadow:0 14px 28px #000b,0 0 16px #91bf7a55}.image-frame[_ngcontent-%COMP%]{padding:12px 12px 0}img[_ngcontent-%COMP%]{display:block;width:100%;height:190px;object-fit:contain;border-radius:12px;background:#0b110d}.card-content[_ngcontent-%COMP%]{padding:16px}.tag[_ngcontent-%COMP%]{color:#a9cc8e;letter-spacing:2px;font-size:.65rem}h2[_ngcontent-%COMP%]{margin:8px 0;color:#d5efbd;font:700 1.35rem Georgia,serif}.description[_ngcontent-%COMP%]{line-height:1.55;color:#d5dfd0}button[_ngcontent-%COMP%]{border:1px solid #b5d696;border-radius:9px;padding:11px 16px;background:#8fb96f;color:#101812;font-weight:700;cursor:pointer}button[_ngcontent-%COMP%]:active{transform:scale(.97);background:#b5d696}"] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MonsterCardComponent, [{
        type: Component,
        args: [{ selector: 'lib-monster-card', standalone: true, imports: [CommonModule], template: `
    <article class="monster-card">
      <div class="image-frame">
        <img [src]="image" [alt]="title">
      </div>
      <div class="card-content">
        <p class="tag">EXPEDIENTE DE HALLOWEEN</p>
        <h2>{{ title }}</h2>
        <p class="description">{{ description }}</p>
        <button type="button" (click)="cardAction.emit()">{{ buttonText }}</button>
      </div>
    </article>
  `, styles: [":host{display:block;margin:20px 0}.monster-card{overflow:hidden;border:2px solid #789b62;border-radius:18px;background:linear-gradient(145deg,#263a2b,#111a14);box-shadow:0 10px 24px #0009,inset 0 0 18px #9ac47718;color:#e7f0df;transition:transform .2s,box-shadow .2s}.monster-card:hover{transform:translateY(-3px);box-shadow:0 14px 28px #000b,0 0 16px #91bf7a55}.image-frame{padding:12px 12px 0}img{display:block;width:100%;height:190px;object-fit:contain;border-radius:12px;background:#0b110d}.card-content{padding:16px}.tag{color:#a9cc8e;letter-spacing:2px;font-size:.65rem}h2{margin:8px 0;color:#d5efbd;font:700 1.35rem Georgia,serif}.description{line-height:1.55;color:#d5dfd0}button{border:1px solid #b5d696;border-radius:9px;padding:11px 16px;background:#8fb96f;color:#101812;font-weight:700;cursor:pointer}button:active{transform:scale(.97);background:#b5d696}\n"] }]
    }], null, { image: [{
            type: Input
        }], title: [{
            type: Input
        }], description: [{
            type: Input
        }], buttonText: [{
            type: Input
        }], cardAction: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MonsterCardComponent, { className: "MonsterCardComponent", filePath: "lib\\monster-card\\monster-card.component.ts", lineNumber: 40 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { MonsterCardComponent };
//# sourceMappingURL=halloween-ui.mjs.map
