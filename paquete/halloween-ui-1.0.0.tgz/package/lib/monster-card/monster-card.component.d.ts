import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class MonsterCardComponent {
    image: string;
    title: string;
    description: string;
    buttonText: string;
    cardAction: EventEmitter<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MonsterCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MonsterCardComponent, "lib-monster-card", never, { "image": { "alias": "image"; "required": false; }; "title": { "alias": "title"; "required": false; }; "description": { "alias": "description"; "required": false; }; "buttonText": { "alias": "buttonText"; "required": false; }; }, { "cardAction": "cardAction"; }, never, never, true, never>;
}
